# coding: utf-8
from __future__ import unicode_literals, division, absolute_import, print_function


__version__ = '0.19.1'
__version_info__ = (0, 19, 1)
