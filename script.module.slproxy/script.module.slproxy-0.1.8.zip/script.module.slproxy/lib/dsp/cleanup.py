import os
import xbmc
import shutil
# try:
#     import sqlite3 as db
# except ImportError:
#     import pysqlite2 as db

__xbmcVersion__ = float(xbmc.getInfoLabel('System.BuildVersion')[0:4])

#clean up old streamlink modules
def remove_old_sl():
    if xbmc.getCondVisibility("System.HasAddon(script.module.streamlink.base)"):
        _path = xbmc.translatePath('special://home/addons')        
        _repo_ids = ['script.module.streamlink.base', 'script.module.streamlink.plugins']

        if __xbmcVersion__ >= 18:
            _repo_ids.append('script.module.streamlink.crypto')     
        
        try:       
            # conn = db.connect(xbmc.translatePath(os.path.join('special://profile/', 'Database', 'addons27.db')))
            # curs = conn.cursor()    
            xbmc.log('[StreamLink_Proxy] Removing old streamlink modules', xbmc.LOGDEBUG)
            for _repo_id in _repo_ids:            
                try:
                    shutil.rmtree(os.path.join(_path, _repo_id))
                except Exception as err:
                    #traceback.print_exc()
                    #xbmc.log('[StreamLink_Proxy] Error removing old streamlink modules.', xbmc.LOGDEBUG)
                    #xbmc.log('[StreamLink_Proxy] %s'%str(err.message), xbmc.LOGDEBUG)
                    pass
                # try:
                #     curs.execute('DELETE FROM addons WHERE addonID = ?', (_repo_id,))
                #     curs.execute('DELETE FROM installed WHERE addonID = ?', (_repo_id,))
                #     curs.execute('DELETE FROM package WHERE addonID = ?', (_repo_id,))
                #     pass
                # except:
                #     #traceback.print_exc()
                #     pass
            # conn.commit()
            # conn.close()
            xbmc.executebuiltin("XBMC.UpdateLocalAddons()")
        except:
            #conn.close()
            pass